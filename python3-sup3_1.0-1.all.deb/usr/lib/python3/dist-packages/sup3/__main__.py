import os
import sys

from system import main

main()
