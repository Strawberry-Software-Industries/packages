import os
import sys

from colorama import Fore

def main():
    print(Fore.GREEN + "SUP3 " + Fore.RESET + Fore.WHITE + "- Setup Utility for Python 3")
    print("*********************************")
    print(Fore.RED + "Usage: " + Fore.RESET + Fore.WHITE + "sup3 " + Fore.CYAN + "[<buildfile>]" + Fore.RESET)

