import strawlib

utils.file.create("hello.py")